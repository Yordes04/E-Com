DELETE FROM produit;
DROP TABLE produit;

DELETE FROM utilisateur;
DROP TABLE utilisateur;

DROP DATABASE ecommerce;