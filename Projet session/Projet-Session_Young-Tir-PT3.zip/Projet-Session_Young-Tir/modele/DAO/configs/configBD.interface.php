<?php	
	interface ConfigBD
	{	
		const BD_HOTE = "localhost";
		const BD_UTILISATEUR = "young";
		const BD_MOT_PASSE = "tir";
		const BD_NOM = "ecommerce";
	}
?>