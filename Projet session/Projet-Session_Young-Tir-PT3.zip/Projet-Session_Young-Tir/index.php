

<!DOCTYPE html>
<html lang="fr">
<head>
<title> Home</title>
<meta charset="utf-8" />
<link rel="stylesheet" type="text/css" href="css/styleLiens.css" />
<link rel="stylesheet" style="text/css" href="style-projet.css">
<link rel="stylesheet" style="text/css" href="Bootstrap5/bootstrap-5.0.2-dist/css/bootstrap.css">
</head>
<body>
	<h1> Page index</h1>
	<h3><a href="Vues/Accueil.html">#1</a> Page d'accueil</h3>
	<h3><a href="Connexion.php">#2</a> Connexion</h3>
	<h3><a href="Cookie_etape1.php">#3</a> Gestion cookie</h3>
</body>
</html>

